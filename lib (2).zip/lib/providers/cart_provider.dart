import 'package:flutter/material.dart';

class Producto {
  final String id;
  final String nombre;
  final double precio;
  int cantidad;

  Producto({
    required this.id,
    required this.nombre,
    required this.precio,
    this.cantidad = 0,
  });
}

class CartProvider with ChangeNotifier {
  final Map<String, Producto> _items = {};

  Map<String, Producto> get items => _items;

  void agregarProducto(Producto producto) {
    if (_items.containsKey(producto.id)) {
      _items[producto.id]!.cantidad++;
    } else {
      _items[producto.id] = Producto(
        id: producto.id,
        nombre: producto.nombre,
        precio: producto.precio,
        cantidad: 1,
      );
    }
    notifyListeners();
  }

  void quitarProducto(String id) {
    if (_items.containsKey(id)) {
      if (_items[id]!.cantidad > 1) {
        _items[id]!.cantidad--;
      } else {
        _items.remove(id);
      }
      notifyListeners();
    }
  }

  int obtenerCantidad(String id) {
    return _items[id]?.cantidad ?? 0;
  }

  double get total {
    return _items.values.fold(0.0, (sum, item) => sum + item.precio * item.cantidad);
  }

  void limpiarCarrito() {
    _items.clear();
    notifyListeners();
  }
}
